import React from 'react'
import "../css/textscroll.css";

const TextScroll = () => {
  return (
    <div>
 <nav class="menu">
  <div class="menu__item">
    <div class="marquee">
      <div class="marquee__inner">
      <p>Let's create something together <a href='/'>EMAIL ME</a></p>
      <p>Let's create something together <a href='/'>EMAIL ME </a></p>
      <p>Let's create something together <a href='/'>EMAIL ME</a></p>
      <p>Let's create something together <a href='/'>EMAIL ME</a></p>
      </div>
    </div>
  </div>
</nav>


    </div>
  )
}

export default TextScroll ; 