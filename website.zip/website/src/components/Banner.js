import React from "react";
import "../css/banner.css";

const Banner = () => {
  return (
    <div className="banner_wrapper">
      <p className="transparent_text">MIRANDA </p>
    </div>
  );
};

export default Banner;
